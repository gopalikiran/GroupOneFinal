module.exports = {
    '': '',
    'db': 'mongodb://127.0.0.1:27017/group1',
    'api_host': 'http://localhost/',
    'port': 3001
  };