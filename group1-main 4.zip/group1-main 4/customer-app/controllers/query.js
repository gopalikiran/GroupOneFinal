const queryRouter = require('express').Router()



// Query 


module.exports = queryRouter